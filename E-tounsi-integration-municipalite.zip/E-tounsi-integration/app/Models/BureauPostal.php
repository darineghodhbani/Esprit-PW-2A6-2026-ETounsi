<?php

class BureauPostal {
    private ?int $id;
    private ?string $nom;
    private ?string $adresse;
    private ?string $ville;

    public function __construct(?int $id, ?string $nom, ?string $adresse, ?string $ville) {
        $this->id = $id;
        $this->nom = $nom;
        $this->adresse = $adresse;
        $this->ville = $ville;
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): void {
        $this->id = $id;
    }

    public function getNom(): ?string {
        return $this->nom;
    }

    public function setNom(?string $nom): void {
        $this->nom = $nom;
    }

    public function getAdresse(): ?string {
        return $this->adresse;
    }

    public function setAdresse(?string $adresse): void {
        $this->adresse = $adresse;
    }

    public function getVille(): ?string {
        return $this->ville;
    }

    public function setVille(?string $ville): void {
        $this->ville = $ville;
    }
}

<?php
$labels=['telephone_contact'=>'Téléphone','nom'=>'Nom','prenom'=>'Prénom(s)','date_naissance'=>'Date de naissance','lieu_naissance'=>'Lieu de naissance','sexe'=>'Sexe','pere_nom_prenom'=>'Père','pere_profession'=>'Profession du père','mere_nom_prenom'=>'Mère','mere_profession'=>'Profession de la mère','numero_acte'=>'Numéro de l’acte','annee_acte'=>'Année de l’acte','type_acte'=>'Origine de l’acte','date_declaration'=>'Date de déclaration','declarant'=>'Déclarant','profession_declarant'=>'Profession du déclarant','tribunal'=>'Tribunal','officier_etat_civil'=>'Officier d’état civil','profession_officier'=>'Qualité de l’officier','epoux'=>'Époux','epouse'=>'Épouse','celebration'=>'Mode de célébration','notaire1'=>'Premier notaire','notaire2'=>'Deuxième notaire','observations'=>'Observations','nom_concerne'=>'Personne concernée','precision_demande'=>'Précisions'];
?>
<article class="content-panel receipt">
 <div class="d-flex justify-content-between flex-wrap gap-3"><div><p class="eyebrow">E-Tounsi · Municipalité</p><span class="badge text-bg-success">Demande envoyée</span><h1 class="page-title mt-2">Récépissé de demande</h1><p>Conservez cette référence pour vos échanges avec la municipalité.</p></div><div class="text-end"><strong>Référence</strong><div class="h4">DM-<?= str_pad((string)$demande['id_demande'],5,'0',STR_PAD_LEFT) ?></div></div></div>
 <hr><dl class="row"><dt class="col-sm-4">Service</dt><dd class="col-sm-8"><?= e($demande['libelle']) ?></dd><dt class="col-sm-4">Date de dépôt</dt><dd class="col-sm-8"><?= e(date('d/m/Y H:i',strtotime($demande['date_depot']))) ?></dd><dt class="col-sm-4">État</dt><dd class="col-sm-8"><?= e(str_replace('_',' ',ucfirst($demande['statut']))) ?></dd>
 <?php if($demande['date_souhaitee']): ?><dt class="col-sm-4">Rendez-vous demandé</dt><dd class="col-sm-8"><?= e($demande['delegation']) ?>, <?= e($demande['gouvernorat']) ?><br><?= e(date('d/m/Y à H:i',strtotime($demande['date_souhaitee']))) ?> · <?= e($demande['statut_rdv']??'en attente de confirmation') ?></dd><?php else: ?><dt class="col-sm-4">Retrait du document</dt><dd class="col-sm-8">Au guichet municipal après notification de mise à disposition.</dd><?php endif; ?>
 <?php if(!empty($demande['document_statut'])): ?><dt class="col-sm-4">Document municipal</dt><dd class="col-sm-8"><?= e($demande['document_type']) ?> · <?= e(str_replace('_',' ',ucfirst($demande['document_statut']))) ?></dd><?php endif; ?>
 <dt class="col-sm-4">Frais</dt><dd class="col-sm-8"><?= e(number_format((float)$demande['frais'],3,',',' ')) ?> DT · <?= e($demande['paiement_statut']??'sans frais') ?></dd><?php if(!empty($demande['paiement_reference'])): ?><dt class="col-sm-4">Référence de paiement</dt><dd class="col-sm-8"><?= e($demande['paiement_reference']) ?></dd><?php endif; ?></dl>
 <?php if($details): ?><h2 class="h5 mt-4">Informations déclarées</h2><dl class="row"><?php foreach($details as $k=>$v): if(!isset($labels[$k])||$v==='')continue; ?><dt class="col-sm-4"><?= e($labels[$k]) ?></dt><dd class="col-sm-8"><?= e(is_scalar($v)?(string)$v:'') ?></dd><?php endforeach; ?></dl><?php endif; ?>
 <div class="no-print d-flex flex-wrap gap-2 mt-4"><button class="button button-dark" type="button" data-print-receipt>Imprimer le récépissé</button><a class="button button-light" href="index.php?page=municipalite-suivi">Mes demandes et notifications</a><?php if(($demande['paiement_statut']??'')==='en_attente'&&$carteActive): ?><form method="post" action="index.php?page=municipalite-payer"><input type="hidden" name="csrf" value="<?= e(csrfToken()) ?>"><input type="hidden" name="id_demande" value="<?= (int)$demande['id_demande'] ?>"><button class="button button-dark" type="submit">Payer par carte bancaire</button></form><?php endif; ?></div>
</article>
<style>
.receipt{max-width:900px;margin:0 auto}
@page{margin:15mm}
@media print{
  body *{visibility:hidden!important}
  .receipt,.receipt *{visibility:visible!important}
  .receipt{position:absolute;inset:0;max-width:none;width:100%;margin:0;border:0!important;box-shadow:none!important}
  .no-print{display:none!important}
}
</style>
<script src="assets/frontoffice/js/municipalite.js?v=print-1"></script>

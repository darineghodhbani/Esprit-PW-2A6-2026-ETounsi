(() => {
  'use strict';
  const mapNode = document.getElementById('delegation-map');
  const governorate = document.getElementById('gouvernorat');
  const delegation = document.getElementById('delegation');
  const map = mapNode ? JSON.parse(mapNode.textContent || '{}') : {};

  if (governorate && delegation) {
    const fillDelegations = () => {
      const options = map[governorate.value] || [];
      delegation.replaceChildren(new Option(options.length ? 'Choisir une délégation' : 'Choisir d’abord un gouvernorat', ''));
      options.forEach((name) => delegation.add(new Option(name, name)));
      delegation.disabled = options.length === 0;
    };
    governorate.addEventListener('change', fillDelegations);
    fillDelegations();
  }

  const celebration = document.getElementById('celebration');
  const updateNotaries = () => {
    const visible = celebration && ['notaires', 'municipalite_et_notaires'].includes(celebration.value);
    document.querySelectorAll('.notary').forEach((group) => {
      group.classList.toggle('d-none', !visible);
      const field = group.querySelector('input');
      field.required = Boolean(visible);
      field.disabled = !visible;
    });
  };
  celebration?.addEventListener('change', updateNotaries);
  updateNotaries();

  const birthType = document.getElementById('birth-type');
  const updateBirthFields = () => {
    const judgment = birthType?.value === 'jugement';
    document.querySelectorAll('.birth-declarant').forEach((group) => {
      group.classList.toggle('d-none', judgment);
      group.querySelector('input').required = !judgment;
    });
    const tribunal = document.querySelector('.birth-tribunal');
    if (tribunal) {
      tribunal.classList.toggle('d-none', !judgment);
      tribunal.querySelector('input').required = Boolean(judgment);
    }
  };
  birthType?.addEventListener('change', updateBirthFields);
  updateBirthFields();

  document.querySelectorAll('[data-print-receipt]').forEach((button) => {
    button.addEventListener('click', () => window.print());
  });
})();

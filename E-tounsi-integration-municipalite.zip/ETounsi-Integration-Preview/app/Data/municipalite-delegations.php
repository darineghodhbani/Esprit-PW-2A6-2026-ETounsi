<?php
declare(strict_types=1);

return [
 'Tunis'=>['Carthage','La Médina','Bab Bhar','Bab Souika','Omrane','Omrane Supérieur','Attahrir','El Menzah','Cité Alkhadhra','Bardo','Séjoumi','Azzouhour','Alhrairia','Sidi Hsine','Ouardia','Kabaria','Sidi Elbéchir','Jebel Jelloud','La Goulette','Le Kram','La Marsa'],
 'Ariana'=>['Ariana Ville','Soukra','Raouède','Kalâat Andalous','Sidi Thabet','Cité Attadhamon','M’nihla'],
 'Manouba'=>['Manouba','Oued Ellil','Tebourba','Battan','Jedaida','Mornaguia','Borj Amri','Douar Hicher'],
 'Ben Arous'=>['Ben Arous','Nouvelle Médina','Mourouj','Hammam Lif','Hammam Chatt','Boumhel Bassatine','Ezzahra','Radès','Megrine','M’hamdia','Fouchana','Mornag'],
 'Nabeul'=>['Nabeul','Dar Chaâbane Elfehri','Béni Khiar','Korba','Menzel Temime','Mida','Kelibia','Hammam Ghezaz','Haouaria','Takelsa','Slimane','Menzel Bouzelfa','Béni Khalled','Grombalia','Bouârgoub','Hammamet'],
 'Bizerte'=>['Bizerte Nord','Jarzouna','Bizerte Sud','Sejnane','Joumine','Mateur','Ghezala','Menzel Bourguiba','Tinja','Utique','Ghar El Melh','Menzel Jemil','El Alia','Ras Jebel'],
 'Zaghouan'=>['Zaghouan','Zériba','Bir Mecharga','Fahs','Nadhour','Saouaf'],
 'Sousse'=>['Sousse Ville','Zaouia Ksiba Thrayat','Sousse Ryadh','Sousse Jawhara','Sousse Sidi Abdelhamid','Hammam Sousse','Akouda','Kalâa Elkébira','Sidi Bouali','Hergla','Enfidha','Bouficha','Koundar','Sidi Elheni','Msaken','Kalâa Ességhira'],
 'Monastir'=>['Monastir','Ouerdanine','Sahline','Zéramdine','Béni Hassan','Jammel','Benbla','Moknine','Bekalta','Teboulba','Ksar Helal','Ksibet Medyouni','Sayada Lamta Bouhjar'],
 'Mahdia'=>['Mahdia','Boumerdes','Ouled Chamekh','Chorbane','Hbira','Souassi','Eljem','Chebba','Malloulech','Sidi Alouane','Ksour Essef'],
 'Sfax'=>['Sfax Ville','Sfax Ouest','Sakiet Ezzit','Sakiet Eddaier','Sfax Sud','Tina','Agareb','Jebeniana','El Amra','El Hencha','Menzel Chaker','Ghraiba','Bir Ali Ben Khelifa','Sekhira','Mahrès','Kerkennah'],
 'Béja'=>['Béja Nord','Béja Sud','Amdoun','Nefza','Teboursouk','Tibar','Testour','Goubellat','Mejez El Bab'],
 'Jendouba'=>['Jendouba','Jendouba Nord','Boussalem','Tabarka','Aïn Draham','Fernana','Ghardimaou','Oued Mliz','Balta Bouaouene'],
 'Le Kef'=>['Kef Ouest','Kef Est','Nebeur','Sakiet Sidi Youssef','Tejerouine','Kalâat Sinane','Kalâa El Khasba','Jerissa','Gsour','Dahmani','Le Sers'],
 'Siliana'=>['Siliana Nord','Siliana Sud','Bouarada','Gâafour','El Aroussa','Le Krib','Bourouis','Makther','Rouhia','Kesra','Bargou'],
 'Kairouan'=>['Kairouan Nord','Kairouan Sud','Chebika','Sebikha','Oueslatia','Haffouz','El Ala','Hajeb El Ayoun','Nasrallah','Cherarda','Bouhajla'],
 'Sidi Bouzid'=>['Sidi Bouzid Ouest','Sidi Bouzid Est','Jelma','Sabbalet Ouled Askar','Bir Hfay','Sidi Ali Ben Aoun','Menzel Bouzayane','Meknassi','Souk Jedid','Mezouna','Regueb','Ouled Haffouz'],
 'Kasserine'=>['Kasserine Nord','Kasserine Sud','Azzouhour','Hassi Ferid','Sbitla','Sbiba','Jedliane','El Ayoun','Tela','Hidra','Foussana','Feriana','Mejel Bel Abbes'],
 'Gabès'=>['Gabès Ville','Gabès Ouest','Gabès Sud','Ghannouch','Metouia','Menzel Habib','Hamma','Matmata','Matmata Nouvelle','Mareth'],
 'Médenine'=>['Médenine Nord','Médenine Sud','Béni Khedach','Ben Guerdane','Zarzis','Djerba Houmt Souk','Djerba Midoun','Djerba Ajim','Sidi Makhlouf'],
 'Gafsa'=>['Gafsa Nord','Sidi Aich','El Ksar','Gafsa Sud','Moulares','Redeyef','Métlaoui','El Mdhilla','El Guettar','Belkhir','Sned'],
 'Tozeur'=>['Tozeur','Degueche','Tameghza','Nefta','Hezoua'],
 'Tataouine'=>['Tataouine Nord','Tataouine Sud','Smar','Bir Lahmer','Ghomrassen','Dhehiba','Remada'],
 'Kébili'=>['Kébili Sud','Kébili Nord','Souk El Ahad','Douz Nord','Douz Sud','El Faouar'],
];

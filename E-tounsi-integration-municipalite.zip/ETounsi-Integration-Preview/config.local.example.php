<?php
// Copiez ce fichier vers config.local.php et adaptez les valeurs à votre MySQL.
// config.local.php est ignoré par Git ; ne le publiez pas.
return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => 'etounsi_validation',
    'user' => 'root',
    'password' => '',
    'app_env' => 'development',
    'recaptcha_site_key' => '',
    'recaptcha_secret_key' => '',
    'konnect_api_key' => '',
    'konnect_wallet_id' => '',
    'konnect_api_base' => 'https://api.sandbox.konnect.network/api/v2',
    'public_url' => 'http://localhost/ETounsi-Integration-Preview',
];
